#ifndef __IEEE802_11_CONN_H__
#define __IEEE802_11_CONN_H__

#define MSG_ENABLE      1
#define MSG_DISABLE     0

typedef enum {
    IEEE802_1X_IDLE           = 0,
    IEEE802_1X_SUCCESS        = 1,
    IEEE802_1X_FAIL           = 2,
    IEEE802_1X_ERROR_TIMEOUT  = 3,
    IEEE802_1X_ERROR_INIT     = 4,
    IEEE802_1X_ERROR_INTERNAL = 5, 
} ieee802_1x_state_t;

extern void ieee802_1x_conn_init();
extern int ieee802_1x_conn_send(ieee802_1x_state_t state);
extern void ieee802_1x_set_wpa_state(ieee802_1x_state_t state);
extern int ieee802_1x_get_wpa_state();
extern void ieee802_1x_set_msg_state(int state);

#endif /* __IEEE802_11_CONN_H__ */

