#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "ieee802_1x_conn.h"


#define MSG_LEVEL_INFO        3
#define MSG_LEVEL_WARNING     4
#define MSG_LEVEL_ERROR       5
    
extern void wpa_printf(int level, const char *fmt, ...);

#define MSG_MAGIC       0x55
#define MAX_SIZE        1

typedef struct msgbuf {
    long mtype;
    char mtext[MAX_SIZE];
} msgbuf_t;

typedef struct {
    ieee802_1x_state_t g_ieee802_1x_state;
    int msg_id;
    int msg_state;
} ieee802_1x_context_t;

static ieee802_1x_context_t g_context;

static void init_value() 
{
    g_context.g_ieee802_1x_state = IEEE802_1X_IDLE;
    g_context.msg_id = -1;
    g_context.msg_state = MSG_DISABLE;
}

static void init_message_queue() 
{
    key_t key = ftok("/var/run",66);
    int id = msgget(key, 0666 | IPC_CREAT); 
    if (id == -1) {
        wpa_printf(MSG_LEVEL_ERROR, "msgget failed with error: %s.", strerror(errno));
    } else {
        g_context.msg_id = id;
    }
    wpa_printf(MSG_LEVEL_INFO, "init msg id:%d.", g_context.msg_id);
}

void ieee802_1x_conn_init()
{
   init_value();
   //init_message_queue(); 
}

int ieee802_1x_conn_send(ieee802_1x_state_t state)
{
    msgbuf_t buf;

    if (g_context.msg_state == 1) {
        g_context.msg_state = MSG_DISABLE;
        init_message_queue(); 
        buf.mtype = MSG_MAGIC;
        buf.mtext[0] = (char)state;
        if(msgsnd(g_context.msg_id, (void *)&buf, MAX_SIZE, 0) < 0)
        {
            wpa_printf(MSG_LEVEL_ERROR, "send msg error:%s.", strerror(errno));
            return -1;
        }
        wpa_printf(MSG_LEVEL_INFO, "send msg state = %d.", state);
   } else {
        wpa_printf(MSG_LEVEL_INFO, "won't send msg.");
   }

    return 0;
}

void ieee802_1x_set_wpa_state(ieee802_1x_state_t state)
{
    g_context.g_ieee802_1x_state = state;
}

int ieee802_1x_get_wpa_state()
{
    return g_context.g_ieee802_1x_state;
}

void ieee802_1x_set_msg_state(int state)
{
    wpa_printf(MSG_LEVEL_INFO, "set msg state:%d.", state);
    g_context.msg_state = state;
}


