#ifndef JV_TYPE_PRIVATE
#define JV_TYPE_PRIVATE

int jvp_number_cmp(jv, jv);
int jvp_number_is_nan(jv);

#endif //JV_TYPE_PRIVATE
